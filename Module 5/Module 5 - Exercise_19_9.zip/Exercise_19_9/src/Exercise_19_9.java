/**
 * @author Chandelor
 */

import java.util.ArrayList;
import java.util.Collections;

public class Exercise_19_9 {
	
  public static void main(String[] args) {
    ArrayList<Integer> list = new ArrayList<Integer>();
    list.add(14);
    list.add(24);
    list.add(4);
    list.add(42);
    list.add(5);
    Exercise_19_9.<Integer>sort(list);
    
    System.out.print(list);
  }
  
  public static <E extends Comparable<E>> void sort(ArrayList<E> list) {
	  /*
	   * This would work to sort the list but I assumed that it wasn't the intended solution.
	   * Collections.sort(list);
	   */
	  
	  ArrayList<E> tempList = new ArrayList<E>();
	  tempList = (ArrayList<E>) list.clone();
	  
	  for(int n = 0; n < list.size() - 1; n++) {
		  for (int j = 0; j < list.size() - 1; j++) {
			  if ((int) list.get(j) > (int) list.get(j + 1)) {
				  list.set(j, list.get(j + 1));
				  list.set(j + 1, tempList.get(j));
				  tempList = (ArrayList<E>) list.clone();
			  }
			  
		  }
			
	  }
		  
  }
  
}
