/**
 * @author Chandelor
 */

import java.util.ArrayList;

public class Exercise_19_3 {
	
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(14);
		list.add(24);
		list.add(14);
		list.add(42);
		list.add(25);
		ArrayList<Integer> newList = removeDuplicates(list);
		System.out.print(newList);
	}
	
	public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list) {
		
		for (int n1 = 0; n1 < list.size(); n1++) {
			for (int n2 = n1 + 1; n2 < list.size();) {
				if (list.get(n1).equals(list.get(n2))) 
					list.remove(n2);
				
				else 
					n2++;
			}
			
		}
		
		return list;
	}
	
}
