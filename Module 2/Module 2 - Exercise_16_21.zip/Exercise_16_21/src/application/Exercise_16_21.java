/*
 * Author: Chandelor
 * Date: 6/16/2023
 */

package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Exercise_16_21 extends Application{
	
	public static void main(String[] args) {
		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		BorderPane pane = new BorderPane();
		Scene scene = new Scene(pane, 250, 150);

		TextField countdownMsg = new TextField("");
		countdownMsg.setEditable(true);
		countdownMsg.setFont(Font.font("Times", 50));
		countdownMsg.setAlignment(Pos.CENTER); 
		countdownMsg.setMaxWidth(245);
		countdownMsg.setPrefWidth(245);
		countdownMsg.setMaxHeight(145);
		countdownMsg.setPrefHeight(145);
		pane.setCenter(countdownMsg);
		
		countdownMsg.setOnKeyPressed(e -> {
			if (e.getCode() == KeyCode.ENTER) {
				countdownMsg.setEditable(false);
				countDownAnimation(countdownMsg);
			}
			
		}); 
		
		primaryStage.setResizable(false);
		primaryStage.setTitle("Countdown");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public void countDownAnimation(TextField text) {
		
		int countdown = Integer.parseInt(text.getText());
		long currentSeconds = System.currentTimeMillis() / 1000;
		
		EventHandler<ActionEvent> eventHandler = e -> {
			long timeElapsed = (System.currentTimeMillis() / 1000) - currentSeconds;
			text.setText(countdown - timeElapsed + "");
			
			if (countdown - timeElapsed == 0) {
				playAudio();
			}
			
		};

		 Timeline animation = new Timeline(new KeyFrame(Duration.millis(250), eventHandler));
		 animation.setCycleCount(countdown * 4);
		 animation.play();
		
	}

	public void playAudio() {
		Media media = new Media("https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3");
		MediaPlayer mediaPlayer = new MediaPlayer(media);
		mediaPlayer.setAutoPlay(true);
	}
	
}
