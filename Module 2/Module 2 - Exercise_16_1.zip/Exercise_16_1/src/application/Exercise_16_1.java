/*
 * Author: Chandelor
 * Date: 6/13/2023
 */

package application;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Exercise_16_1 extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		BorderPane pane = new BorderPane();
		
		HBox hBoxRadioButtons = new HBox(5);
		RadioButton rbRed = new RadioButton("Red");
		RadioButton rbYellow = new RadioButton("Yellow");
		RadioButton rbBlack = new RadioButton("Black");
		RadioButton rbOrange = new RadioButton("Orange");
		RadioButton rbGreen = new RadioButton("Green");
		ToggleGroup group = new ToggleGroup();
		
		rbRed.setToggleGroup(group);
		rbYellow.setToggleGroup(group);
		rbBlack.setToggleGroup(group);
		rbOrange.setToggleGroup(group);
		rbGreen.setToggleGroup(group);
		
		hBoxRadioButtons.getChildren().addAll(rbRed, rbYellow, rbBlack, rbOrange, rbGreen);
		hBoxRadioButtons.setAlignment(Pos.TOP_CENTER);
		
		HBox hBoxMovementButtons = new HBox(2);
		
		Button btLeft = new Button("<=");
		Button btRight = new Button("=>");

		hBoxMovementButtons.getChildren().addAll(btLeft, btRight);
		hBoxMovementButtons.setAlignment(Pos.BOTTOM_CENTER);
		
		Pane textPane = new Pane();
		Text text = new Text(20, 20, "Programming is fun");
		textPane.setStyle("-fx-border-color: black");
		text.setFill(Color.BLACK);
		text.setFont(Font.font("Times", 20));
		textPane.getChildren().add(text);
		
		pane.setTop(hBoxRadioButtons);
		pane.setCenter(textPane);
		pane.setBottom(hBoxMovementButtons);
		
		rbRed.setOnAction(e -> text.setFill(Color.RED));
		rbYellow.setOnAction(e -> text.setFill(Color.YELLOW));
		rbBlack.setOnAction(e -> text.setFill(Color.BLACK));
		rbOrange.setOnAction(e -> text.setFill(Color.ORANGE));
		rbGreen.setOnAction(e -> text.setFill(Color.GREEN));
		
		btLeft.setOnAction(e -> {
			if (text.getX() - 1 >= 0) {
				text.setX(text.getX() - 1);
			}
			
		});
		
		btRight.setOnAction(e -> {
			if (text.getX() + 1 <= 303) {
				text.setX(text.getX() + 1);
			}
		
		});
		
		Scene scene = new Scene(pane, 480, 300);
		primaryStage.setResizable(false);
		primaryStage.setTitle("Exercise_16_1");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
