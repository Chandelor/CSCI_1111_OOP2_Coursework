/**
 * @author Chandelor
 */
import java.util.Scanner;

public class Exercise_18_9 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		String reversedString = "";
		
		System.out.print("Enter a string to reverse: ");
		String userString = input.nextLine();
		int stringLength = userString.length();
		
		System.out.println(userString + " spelt backwards is: " + reverseDisplay(userString, reversedString, stringLength));
	}
	
	public static String reverseDisplay(String userString, String reversedString, int stringLength) {
		
		if (userString.length() == reversedString.length()) {
			return reversedString;
		}
		
		else {
			reversedString += userString.charAt(stringLength - 1);
			return reverseDisplay(userString, reversedString, stringLength = stringLength - 1);
		}
		
	}

}
