/*
 * Author: Chandelor
 * Date: 6/26/2023 
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Exercise_17_15 {

public static void main(String[] args) throws IOException {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a file name to decrypt: ");
		String filePath = input.nextLine();
		File userFile = new File(filePath);
		
		System.out.print("Enter name for output file: ");
		String newFileName = input.nextLine();
		File newFile = new File(newFileName);
		
		FileOutputStream fileOutput = new FileOutputStream(newFile);
		FileInputStream fileInput = new FileInputStream(userFile);
		
		copyAndDecryptFile(fileOutput, fileInput);
	}
	
	public static void copyAndDecryptFile(FileOutputStream fileOutput, FileInputStream fileInput) throws IOException {
		
        try {
            for (int n = 0; (n = fileInput.read()) != -1;) fileOutput.write(n - 5);
        }
        
        finally {
            if (fileOutput != null) fileOutput.close();
            if (fileInput != null) fileInput.close();
        }
        
	}

}
