/*
 * Author: Chandelor
 * Date: 6/22/2023
 */

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class Exercise_17_3 {

	public static void main(String[] args) throws Exception {
		
		ArrayList<Integer> dataInputArray = new ArrayList<>();		
		
		try (DataOutputStream dataOutput = new DataOutputStream(new FileOutputStream("Exercise_17_3.txt"));) {
			for (int n = 0; n < 100; n++) {
				dataOutput.writeInt((int)(Math.random() * 999) + 0);
			}
			
			dataOutput.close();
		}
		
		try (DataInputStream dataInput = new DataInputStream(new FileInputStream("Exercise_17_3.txt"));) {
			while (true) {
				dataInputArray.add(dataInput.readInt());
				System.out.print(dataInput.readInt() + " ");
			}
			
		}
		
		catch (EOFException ex) {
		}
		
		System.out.println("\nSum of Numbers: " + returnSum(dataInputArray));
	}
	
	public static int returnSum(ArrayList<Integer> array) {
		int sum = 0;
		for(int n = 0; n < array.size(); n++) {
		    sum += array.get(n);
		}
		
		return sum;
	}

}
