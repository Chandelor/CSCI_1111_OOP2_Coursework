/*
 * Author: Chandelor
 * Date: 6/20/2023
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Exercise_17_1 {

	public static void main(String[] args) throws Exception {
		
		 try (FileOutputStream fileOutput = new FileOutputStream("Exercise17_01.txt");) {
			 
			 for (int integerCount = 1; integerCount <= 100; integerCount++) {
				 fileOutput.write((int)(Math.random() * 999) + 1); 
			 }
			 
		 }
	
		 try (FileInputStream fileInput = new FileInputStream("Exercise17_01.txt");) {
			 
			 for (int value; (value = fileInput.read()) != -1;) {
				 System.out.print(value + " ");
			 }
			 
		 }
		 
	}

}
