import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Exercise_17_7 {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		
        Loan loan1 = new Loan();
        Loan loan2 = new Loan(1.8, 10, 10000);
        
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("Exercise_17_07.dat"));) {
            output.writeObject(loan1);
            output.writeObject(loan2);
            output.close();
        } 
        
        outputData();
	}
	
	public static void outputData() throws FileNotFoundException, IOException, ClassNotFoundException {
		
		try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("Exercise_17_07.dat"));) {
			while(true) {
				Loan readLoan = (Loan)input.readObject();
	        	System.out.println("Annual Interest Rate: " + readLoan.getAnnualInterestRate() + "%");
	        	System.out.println("Number of Years: " + readLoan.getNumberOfYears());
	        	System.out.println("Loan Amount: $" + readLoan.getLoanAmount());
	        	System.out.println();
        	}
			
        }
		
        catch(EOFException ex) {
        	System.out.println("End of the File!");
        }
		
	}

}
