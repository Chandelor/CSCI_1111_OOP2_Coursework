/*
 * @author Chandelor
 * Date: 6/8/2023
 */

package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.geometry.Pos;

public class Exercise_15 extends Application{
	
	@Override
	public void start(Stage primaryStage) {
		
		Pane pane = new Pane();
		HBox hbox = new HBox();
		Circle circle = new Circle();
		BorderPane borderPane = new BorderPane();

		Button btUp = new Button("Up");
		Button btDown = new Button("Down");
		Button btLeft = new Button("Left");
		Button btRight = new Button("Right");
		
		circle.centerXProperty().bind(pane.widthProperty().divide(2));
		circle.centerYProperty().bind(pane.heightProperty().divide(2));
		circle.setRadius(50);
		circle.setStroke(Color.BLACK);
		circle.setFill(Color.WHITE);
		pane.getChildren().add(circle);
		hbox.getChildren().add(btUp);
		hbox.getChildren().add(btDown);
		hbox.getChildren().add(btLeft);
		hbox.getChildren().add(btRight);
		borderPane.setCenter(pane);
		borderPane.setBottom(hbox);
		hbox.setAlignment(Pos.CENTER);
		hbox.setSpacing(10);
		
		Scene scene = new Scene(borderPane, 360, 300);
		primaryStage.setTitle("Move the Ball");
		primaryStage.setScene(scene);
		primaryStage.show();
		circle.requestFocus();
		
		circle.centerXProperty().unbind();
		circle.centerYProperty().unbind();
		
		btUp.setOnAction(e -> {
			if ((circle.getCenterY() - 50) - 1 > 0) {
				circle.setCenterY(circle.getCenterY() - 1);
			}
			
		});
		
		btDown.setOnAction(e -> {
			if ((circle.getCenterY() + 50) + 1 < scene.getHeight()) {
				circle.setCenterY(circle.getCenterY() + 1);
			}
			
		});
		
		btLeft.setOnAction(e -> {
			if ((circle.getCenterX() - 50) - 1 > 0) {
				circle.setCenterX(circle.getCenterX() - 1);
			}
			
		});
			
		btRight.setOnAction(e -> {
			if ((circle.getCenterX() + 50) + 1 < scene.getWidth()) {
				circle.setCenterX(circle.getCenterX() + 1);
			}
			
		});	
		
	}
	
	public static void main(String[] args) {
		launch(args);
	
	}

}
