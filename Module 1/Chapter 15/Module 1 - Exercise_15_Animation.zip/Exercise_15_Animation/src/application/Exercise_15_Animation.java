/*
 * Author: Chandelor
 * Date: 6/9/2023
 */
package application;

import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.paint.Color;
import javafx.scene.layout.StackPane;

public class Exercise_15_Animation extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		StackPane pane =  new StackPane();
		
		Polygon pentagon = new Polygon();
		pentagon.setFill(Color.WHITE);
		pentagon.setStroke(Color.BLACK);
		ObservableList<Double> list = pentagon.getPoints();
		
		double centerX = 400 / 2, centerY = 400 / 2;
		double radius = Math.min(400, 400) * 0.2;

		for (int i = 0, s = 5; i < s; i++) {
			list.add(centerX + radius * Math.cos(2 * i * Math.PI / s)); 
			list.add(centerY - radius * Math.sin(2 * i * Math.PI / s));
		}   
	
		Rectangle rectangle = new Rectangle(178, 185, 60, 30);
		rectangle.setFill(Color.BLACK);
		rectangle.setStroke(Color.BLACK);
		
		pentagon.setRotate(54);
		pane.getChildren().add(pentagon);
		pane.getChildren().add(rectangle);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.millis(3000));
		pt.setPath(pentagon);
		pt.setNode(rectangle);
		pt.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
		pt.setCycleCount(Timeline.INDEFINITE);
		pt.setAutoReverse(false);
		pt.play();
		
		FadeTransition ft = new FadeTransition(Duration.millis(3000), rectangle);
		ft.setFromValue(1.0);
		ft.setToValue(0.1);
		ft.setCycleCount(Timeline.INDEFINITE);
		ft.setAutoReverse(true);
		ft.play();
		
		pane.setOnMousePressed(e -> {
			pt.pause();
			ft.pause();
		});
		
		pane.setOnMouseReleased(e ->{
			pt.play();
			ft.play();
		});
		
		Scene scene = new Scene(pane, 400, 400);		
		primaryStage.setTitle("Exercise_15_Animation");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
}
